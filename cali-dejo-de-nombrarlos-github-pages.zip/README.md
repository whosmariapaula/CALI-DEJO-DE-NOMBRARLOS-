# Cali dejó de nombrarlos — versión estática para GitHub Pages

Esta carpeta contiene una versión publicable directamente en GitHub Pages. No necesita Node.js, npm, Vite, GitHub Actions ni un proceso de build.

## Archivos

- `index.html`: documento de entrada y carga de dependencias.
- `styles.css`: estilos originales del especial.
- `app.js`: componentes, navegación, interacciones y montaje visual (conserva JSX).
- `data.js`: contenido editable: casos, línea de tiempo, archivo, equipo, estado y productos.

## Publicar en GitHub Pages

1. Crea un repositorio en GitHub.
2. Sube **todos los archivos de esta carpeta a la raíz** del repositorio (`index.html` debe quedar en la raíz).
3. En GitHub abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`. Guarda.
6. Espera a que GitHub Pages publique la URL que aparecerá en esa misma sección.

No configures workflows ni GitHub Actions.

## Ejecutar localmente

Puedes abrir `index.html` en un navegador moderno. Para evitar restricciones del navegador al cargar scripts externos, también puedes servir la carpeta con cualquier servidor estático sencillo. No hay instalación ni compilación.

## Editar contenido

Abre `data.js`. Allí puedes modificar las colecciones:

- `cases`: casos y fichas de investigación.
- `timeline`: hitos cronológicos.
- `archiveItems`: categorías y piezas del archivo.
- `team`: integrantes, perfiles y responsabilidades.
- `projectStatus`: estado de los componentes.
- `productConfig`: títulos, descripciones y estado de los productos.

Conserva los nombres de las propiedades para que las tarjetas y fichas sigan funcionando. Utiliza `[CONTENIDO PENDIENTE]`, `[DATOS POR VERIFICAR]` o estados equivalentes hasta contar con información sustentada. No agregues testimonios, fechas, ubicaciones ni fuentes no verificadas.

## Integrar los productos periodísticos

Los módulos de reportaje, audio y Guardián de la Memoria ya están reservados en `app.js`. Para incorporar los contenidos definitivos, actualiza el marcado del módulo correspondiente y enlaza únicamente recursos autorizados.

El Guardián actual es una demostración explícita: no consulta un corpus ni genera respuestas documentales. Cuando exista una integración real, reemplaza el panel `.chat-window` por el iframe o la interfaz aprobada y documenta el servicio utilizado.

## Dependencias externas

La versión estática carga React 18, ReactDOM 18 y Babel Standalone desde un CDN, además de las fuentes de Google Fonts. Esto permite conservar la estructura JSX y las interacciones originales sin proceso de build. Por tanto, la primera carga requiere conexión a internet y disponibilidad de esos CDN. Si se requiere funcionamiento completamente autónomo/offline, habrá que distribuir también las bibliotecas localmente.

## Nota sobre compatibilidad

La aplicación y el diseño provienen de la versión Vite existente; se retiró la dependencia del servidor de desarrollo y del sistema de módulos de Vite. El navegador transforma el JSX al vuelo mediante Babel Standalone. No es un build ni requiere acciones de GitHub.
