/*
  CONTENIDO EDITABLE DEL ESPECIAL
  Agrega, modifica o elimina objetos en estas colecciones.
  No publiques nombres, fechas, ubicaciones, imágenes ni testimonios sin verificar
  y contar con los permisos correspondientes.
*/

const cases = [
  {
    id: "caso-principal",
    name: "Caso principal",
    type: "CASO EN INVESTIGACIÓN",
    location: "[UBICACIÓN POR VERIFICAR]",
    period: "[PERIODO POR DOCUMENTAR]",
    status: "En investigación",
    summary: "Este espacio está reservado para el caso principal de la investigación. La ficha se publicará cuando la información esté documentada y contrastada.",
    image: "",
    whatItWas: "[CONTENIDO PENDIENTE]",
    whatHappened: "[DATOS POR VERIFICAR]",
    currentState: "[ESTADO ACTUAL POR VERIFICAR]",
    testimony: "[TESTIMONIO PENDIENTE]",
    sources: []
  },
  {
    id: "caso-contraste",
    name: "Caso de contraste",
    type: "CASO DE CONTRASTE",
    location: "[UBICACIÓN POR VERIFICAR]",
    period: "[PERIODO POR DOCUMENTAR]",
    status: "En investigación",
    summary: "Un segundo caso permitirá contrastar trayectorias, transformaciones y formas de permanencia de la memoria cultural.",
    image: "",
    whatItWas: "[CONTENIDO PENDIENTE]",
    whatHappened: "[DATOS POR VERIFICAR]",
    currentState: "[ESTADO ACTUAL POR VERIFICAR]",
    testimony: "[TESTIMONIO PENDIENTE]",
    sources: []
  }
];

const timeline = [
  { year: "1990", title: "Comienza el periodo de observación", detail: "La investigación toma la década de 1990 como punto de partida. Los hitos específicos se incorporarán con respaldo documental.", status: "Marco temporal" },
  { year: "1990–2026", title: "Transformaciones por reconstruir", detail: "Cierres, cambios de uso, desplazamientos, permanencias y nuevas formas de participación cultural: cada acontecimiento deberá verificarse.", status: "En investigación" },
  { year: "2026", title: "Presente de la investigación", detail: "El proyecto reconstruye qué permanece de estas memorias y quiénes las mantienen, resignifican o intentan recuperar.", status: "Periodo de cierre" }
];

const archiveItems = [
  { id: "fotografias", kind: "IMÁGENES", title: "Fotografías históricas y actuales", description: "Imágenes autorizadas que permitan observar los espacios, sus transformaciones y las prácticas culturales.", symbol: "▧", status: "Por incorporar" },
  { id: "hemeroteca", kind: "PRENSA", title: "Recortes y archivos periodísticos", description: "Noticias, entrevistas, crónicas, reseñas, agendas culturales y fotografías de prensa.", symbol: "▤", status: "Por incorporar" },
  { id: "documentos", kind: "DOCUMENTOS", title: "Documentos institucionales", description: "Planes, políticas culturales, presupuestos, informes, convocatorias, mapas e inventarios.", symbol: "▣", status: "Por incorporar" },
  { id: "voces", kind: "MEMORIA ORAL", title: "Fragmentos de entrevistas", description: "Voces de protagonistas, vecinos, públicos, nuevas generaciones y fuentes de contraste.", symbol: "〝", status: "En reportería" },
  { id: "sonidos", kind: "AUDIO", title: "Sonidos y registros audiovisuales", description: "Registros sonoros, radio, televisión, grabaciones y materiales autorizados.", symbol: "◖", status: "Por incorporar" },
  { id: "mapas", kind: "CARTOGRAFÍA", title: "Mapas y registros urbanos", description: "Mapas culturales, cambios de uso del suelo, datos urbanos y documentos de contexto.", symbol: "⌖", status: "Por incorporar" }
];

const team = [
  {
    name: "María Paula Buitrago Toro",
    degree: "Comunicación Social y Periodismo",
    role: ["Investigación periodística", "Reporterías", "Producción de contenidos", "Desarrollo narrativo", "Investigación documental", "Gestión del proyecto digital"],
    mark: "MP"
  },
  {
    name: "Dana Moreno López",
    degree: "Comunicación Social y Periodismo",
    role: ["Investigación", "Reporterías", "Producción de contenidos", "Desarrollo narrativo", "Apoyo audiovisual y documental"],
    mark: "DM"
  },
  {
    name: "José Mauricio Alarcón Lozada",
    degree: "Comunicación Social y Periodismo",
    role: ["Investigación", "Producción audiovisual", "Reporterías", "Desarrollo técnico/narrativo", "Apoyo en el componente de inteligencia artificial"],
    mark: "JM"
  }
];

const projectStatus = [
  ["Investigación", "En desarrollo"],
  ["Casos", "En investigación y verificación"],
  ["Fuentes humanas", "En reportería"],
  ["Archivo documental", "En construcción"],
  ["Reportaje escrito", "En producción"],
  ["Podcast / audiovisual", "En producción"],
  ["Guardián de la Memoria", "Prototipo desarrollado · en integración"],
  ["Plataforma web", "En construcción"]
];

const productConfig = {
  report: {
    title: "Los lugares que Cali dejó de nombrar",
    subtitle: "El reportaje principal: reconstruir un caso central y ponerlo en diálogo con un segundo caso.",
    status: "En producción",
    cover: "REPORTAJE / MULTIMEDIA",
    placeholder: "[REPORTAJE, FOTOGRAFÍAS, DATOS, CITAS, DOCUMENTOS Y MULTIMEDIA PENDIENTES]"
  },
  audio: {
    title: "Memorias que todavía suenan",
    subtitle: "Una experiencia narrativa construida con las voces de quienes vivieron, habitaron o transformaron estos espacios.",
    status: "En producción",
    cover: "AUDIOVISUAL / PODCAST",
    placeholder: "[REPRODUCTOR, PORTADA, PARTICIPANTES, FRAGMENTOS Y TRANSCRIPCIÓN PENDIENTES]"
  }
};


// Datos públicos editables para la versión estática.
window.CDNData = { cases, timeline, archiveItems, team, projectStatus, productConfig };
