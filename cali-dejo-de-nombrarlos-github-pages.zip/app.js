const { useEffect, useMemo, useState } = React;
const { cases, timeline, archiveItems, team, projectStatus, productConfig } = window.CDNData;

const navItems = [
  ["La pregunta", "pregunta"], ["La investigación", "investigacion"],
  ["Lugares", "lugares"], ["Archivo", "archivo"], ["Las historias", "historias"],
  ["Guardián", "guardian"], ["Transparencia", "transparencia"]
];

function scrollTo(id) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function Eyebrow({ children, light = false }) {
  return <div className={`eyebrow ${light ? "eyebrow-light" : ""}`}><span />{children}</div>;
}

function SectionHead({ kicker, title, intro, dark = false, number }) {
  return (
    <div className={`section-head ${dark ? "on-dark" : ""}`}>
      <div>
        <Eyebrow light={dark}>{kicker}</Eyebrow>
        <h2>{title}</h2>
      </div>
      {intro && <p>{intro}</p>}
      {number && <span className="section-number">{number}</span>}
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeNav, setActiveNav] = useState("pregunta");
  const [activeCase, setActiveCase] = useState(null);
  const [activeArchive, setActiveArchive] = useState("fotografias");
  const [openEthics, setOpenEthics] = useState(0);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState([]);
  const [showAllRoles, setShowAllRoles] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress(max > 0 ? (window.scrollY / max) * 100 : 0);
      const sections = navItems.map(([, id]) => document.getElementById(id)).filter(Boolean);
      const current = sections.filter(el => el.getBoundingClientRect().top < 170).pop();
      if (current) setActiveNav(current.id);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const selectedArchive = useMemo(
    () => archiveItems.find(item => item.id === activeArchive) || archiveItems[0],
    [activeArchive]
  );

  function submitQuestion(e) {
    e.preventDefault();
    const q = chatInput.trim();
    if (!q) return;
    setChatMessages(prev => [...prev, { from: "user", text: q }]);
    setChatInput("");
    setTimeout(() => {
      setChatMessages(prev => [...prev, {
        from: "guardian",
        text: "El Guardián todavía está en integración con el corpus documental y testimonial verificado. No voy a inventar una respuesta. Cuando el archivo esté conectado, podré responder con referencias a sus fuentes y señalar vacíos o versiones en contraste."
      }]);
    }, 250);
  }

  return (
    <div className="site-shell">
      <div className="reading-progress" style={{ width: `${scrollProgress}%` }} />
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="Volver al inicio">
          <span className="brand-mark">CDN</span>
          <span className="brand-name">CALI DEJÓ<br/>DE NOMBRARLOS</span>
        </a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Abrir navegación">
          <span>{menuOpen ? "CERRAR" : "MENÚ"}</span><b>{menuOpen ? "×" : "+"}</b>
        </button>
        <nav className={menuOpen ? "nav-open" : ""}>
          {navItems.map(([label, id]) => (
            <a key={id} className={activeNav === id ? "active" : ""} href={`#${id}`} onClick={() => setMenuOpen(false)}>{label}</a>
          ))}
        </nav>
        <span className="topbar-tag">ESPECIAL / 2026</span>
      </header>

      <main>
        <section className="hero" id="inicio">
          <div className="hero-grain" />
          <div className="hero-topline"><span>UN PROYECTO DE PERIODISMO Y MEMORIA CULTURAL</span><span>CALI · COLOMBIA · 1990—2026</span></div>
          <div className="hero-content">
            <div className="hero-kicker"><i /> ESPECIAL PERIODÍSTICO DIGITAL <i /></div>
            <h1>Cali dejó<br/><em>de</em> nombrarlos<span className="title-period">.</span></h1>
            <div className="hero-bottom">
              <p className="hero-deck">Historias de los espacios, personajes y memorias culturales que alguna vez hicieron parte de Cali y hoy han perdido visibilidad.</p>
              <div className="hero-stamp"><span>ARCHIVO<br/>ABIERTO</span><b>✳</b><small>MEMORIA<br/>EN MOVIMIENTO</small></div>
            </div>
          </div>
          <div className="hero-collage" aria-hidden="true">
            <div className="collage-paper paper-one"><span>HEMEROTECA<br/>DE LO QUE FUIMOS</span><b>✳</b></div>
            <div className="collage-photo"><div className="photo-lines" /><span>LO QUE LA CIUDAD<br/>YA NO NOMBRA</span></div>
            <div className="collage-tape">NO OLVIDAR</div>
            <div className="collage-map">3°27' N<br/>76°32' O</div>
          </div>
          <div className="hero-footer"><span>UNA CIUDAD TAMBIÉN SE CUENTA POR LO QUE DEJA DE NOMBRAR.</span><button onClick={() => scrollTo("pregunta")}>ENTRAR A LA INVESTIGACIÓN <b>↓</b></button></div>
        </section>

        <section className="question-section" id="pregunta">
          <div className="question-side"><Eyebrow>01 / LA PREGUNTA</Eyebrow><span className="vertical-note">MEMORIA · CIUDAD · AUSENCIA</span></div>
          <div className="question-main">
            <p className="lead-in">No todo lo que desaparece deja de existir.</p>
            <h2>¿Qué pierde Cali cuando desaparecen, se transforman o dejan de nombrarse los espacios y personajes que construyeron parte de su memoria cultural?</h2>
            <div className="question-bottom"><span className="asterisk">✳</span><p>Quizá no se pierde solamente un edificio. También una forma de encontrarse, una práctica cultural, una comunidad y una manera particular de vivir la ciudad.</p></div>
          </div>
          <div className="question-scribble" aria-hidden="true">¿Y SI<br/>PREGUNTAR<br/>FUERA UNA<br/>FORMA DE<br/>RECORDAR?</div>
        </section>

        <section className="problem-section" id="investigacion">
          <div className="problem-grid">
            <div className="problem-copy">
              <Eyebrow light>02 / EL PROBLEMA</Eyebrow>
              <h2>La ciudad cambia.<br/><em>¿Qué queda</em><br/>de sus historias?</h2>
              <p>Cali dejó de nombrarlos investiga qué ocurre con espacios, personajes y prácticas culturales que hicieron parte de la vida cotidiana, pero que con el tiempo cerraron, cambiaron de uso, fueron desplazados, desaparecieron o dejaron de ocupar un lugar visible en la memoria colectiva.</p>
              <p>La mirada se concentra en espacios cotidianos, independientes, atípicos o relacionados con la cultura popular caleña, y en quienes participaron en la construcción de esas escenas.</p>
              <div className="period-chip"><span>PERIODO DE INVESTIGACIÓN</span><b>1990 — 2026</b></div>
            </div>
            <div className="problem-art">
              <div className="art-circle"><span>LO QUE<br/>PERMANECE</span><b>?</b></div>
              <div className="art-note note-a">UN LUGAR<br/>PUEDE CAMBIAR.</div>
              <div className="art-note note-b">UNA MEMORIA<br/>PUEDE QUEDARSE.</div>
              <div className="art-rip" />
              <div className="art-index">FIG. 01 / CIUDAD EN CAPAS</div>
            </div>
          </div>
          <div className="hypothesis-strip">
            <span className="strip-label">HIPÓTESIS DE TRABAJO</span>
            <p>La pérdida de visibilidad cultural no ocurre de manera aislada: puede resultar de la combinación de cierres, desplazamientos, falta de recursos, cambios urbanos y sociales, relevo generacional y nuevas formas de participación.</p>
            <small>Estas causas no son conclusiones anticipadas: cada una deberá comprobarse o descartarse mediante reportería.</small>
          </div>
        </section>

        <section className="scope-section">
          <div className="scope-top"><Eyebrow>03 / LO QUE MIRAMOS</Eyebrow><span>NO SOLO EDIFICIOS. NO SOLO RECUERDOS.</span></div>
          <div className="scope-intro"><h2>La memoria cultural<br/>también vive en...</h2><p>La ciudad no construye su memoria únicamente a través de monumentos, museos o instituciones. También se construye en los lugares cotidianos y en las personas que los hacen posibles.</p></div>
          <div className="scope-tiles">
            {[
              ["01","TEATROS","Un escenario también puede ser un punto de encuentro."],
              ["02","SALAS DE CINE","Pantallas, públicos y rituales compartidos."],
              ["03","BARRIOS","La memoria se transmite en las calles."],
              ["04","ESCENAS MUSICALES","Sonidos que cuentan una época."],
              ["05","COLECTIVOS","Prácticas culturales que crean comunidad."],
              ["06","PERSONAJES","Quienes sostienen y transforman una escena."]
            ].map(([n,t,d],i)=><article className={`scope-tile tile-${i+1}`} key={n}><span>{n}</span><div><h3>{t}</h3><p>{d}</p></div><b>↗</b></article>)}
          </div>
        </section>

        <section className="method-section">
          <SectionHead kicker="04 / CÓMO INVESTIGAMOS" title={<>Del recuerdo<br/><em>a la evidencia.</em></>} intro="La narrativa parte del presente para reconstruir una historia que pudo quedar oculta o desplazada. La memoria se escucha; los hechos se contrastan." />
          <div className="method-track">
            {[
              ["01","REPORTERÍA","Entrevistas y observación directa.","◉"],
              ["02","MEMORIA ORAL","Reconstrucción de experiencias y recuerdos.","〝"],
              ["03","ARCHIVO","Fotografías, prensa, documentos, afiches y registros.","▤"],
              ["04","DATOS","Información institucional, presupuestos e indicadores.","⌗"],
              ["05","INTELIGENCIA ARTIFICIAL","Organización, relación y exploración del archivo.","✳"],
              ["06","VERIFICACIÓN","Contraste entre testimonios, documentos y datos.","✓"],
              ["07","NARRATIVA","Construcción de los contenidos periodísticos.","↗"]
            ].map(([n,t,d,s],i)=><div className="method-step" key={n}><div className="step-symbol">{s}</div><span>{n}</span><h3>{t}</h3><p>{d}</p>{i!==6&&<b className="step-arrow">→</b>}</div>)}
          </div>
          <div className="method-note"><span>CRITERIO EDITORIAL</span><p>Las posibles causas —falta de recursos, decisiones institucionales, cambios de uso del suelo o relevo generacional, entre otras— se investigan; no se presentan como hechos probados antes de verificarlos.</p></div>
        </section>

        <section className="cases-section" id="lugares">
          <div className="cases-heading"><div><Eyebrow light>05 / CASOS Y LUGARES</Eyebrow><h2>Una ciudad.<br/><em>Muchas ausencias.</em></h2></div><p>La investigación trabaja con un caso principal y un caso de contraste. Las fichas se activarán con información sustentada por fuentes humanas y documentales.</p></div>
          <div className="case-cards">
            {cases.map((item,i)=><button className={`case-card case-${i+1}`} key={item.id} onClick={()=>setActiveCase(item)}>
              <div className="case-image"><span className="case-image-label">{item.type}</span><div className="case-image-art"><b>{i===0?"¿":"↗"}</b><span>{i===0?"ARCHIVO EN CONSTRUCCIÓN":"CASO POR DOCUMENTAR"}</span></div><span className="case-number">0{i+1}</span></div>
              <div className="case-info"><div className="case-meta"><span>{item.period}</span><span className="status-dot">{item.status}</span></div><h3>{item.name}</h3><p>{item.summary}</p><span className="case-link">ABRIR FICHA <b>↗</b></span></div>
            </button>)}
          </div>
          <div className="case-footnote">Los nombres, lugares, fechas y materiales se incorporarán únicamente cuando estén investigados y verificados.</div>
        </section>

        <section className="map-section">
          <div className="map-heading"><Eyebrow>06 / CARTOGRAFÍA DE LA MEMORIA</Eyebrow><h2>Cali que<br/><em>ya no vemos.</em></h2><p>Un mapa para ubicar las historias investigadas. Los marcadores actuales son referencias de interfaz: no representan lugares reales.</p></div>
          <div className="map-board">
            <div className="map-topline"><span>MAPA DE MEMORIA / CALI</span><span>CAPA 01 — PLACEHOLDERS</span></div>
            <div className="map-canvas">
              <svg className="city-lines" viewBox="0 0 900 480" preserveAspectRatio="none" aria-hidden="true">
                <path d="M-20 80 L180 140 360 65 540 120 720 40 940 105 M-20 180 L180 230 340 160 530 210 740 145 940 200 M-20 300 L180 340 360 270 550 325 740 250 940 310 M100 -20 L150 500 M280 -20 L320 500 M480 -20 L510 500 M670 -20 L700 500 M830 -20 L790 500" />
                <path className="river" d="M-30 410 C130 340 170 440 300 370 S480 330 570 390 S760 450 930 350" />
                <path className="district" d="M40 30 L300 20 380 180 250 280 50 220 Z M540 20 L850 20 870 210 680 250 520 150 Z M320 280 L580 230 730 450 420 460 Z" />
              </svg>
              <div className="map-compass">N<br/><b>↑</b></div>
              {[
                {x:27,y:28,n:"A",label:"PLACEHOLDER 01"},
                {x:57,y:49,n:"B",label:"PLACEHOLDER 02"},
                {x:42,y:72,n:"C",label:"PLACEHOLDER 03"}
              ].map(p=><button key={p.n} className="map-pin" style={{left:`${p.x}%`,top:`${p.y}%`}} onClick={()=>setActiveCase(cases[p.n==="A"?0:1])} aria-label={p.label}><span>{p.n}</span></button>)}
              <div className="map-watermark">CALI<br/><i>MEMORIA EN CAPAS</i></div>
              <div className="map-legend"><span><i className="legend-pin" /> PUNTO POR VERIFICAR</span><small>ESQUEMA GRÁFICO · NO ES CARTOGRAFÍA GEORREFERENCIADA</small></div>
            </div>
            <div className="map-bottom"><span>LOS PUNTOS DEFINITIVOS SE PUBLICARÁN DESPUÉS DE LA VERIFICACIÓN.</span><span>ESCALA / EDITORIAL</span></div>
          </div>
        </section>

        <section className="timeline-section">
          <div className="timeline-header"><Eyebrow light>07 / TIEMPO Y TRANSFORMACIÓN</Eyebrow><h2>1990 <span>→</span> 2026</h2><p>Una línea de tiempo abierta. Los hitos concretos se sumarán a medida que existan fechas y fuentes verificadas.</p></div>
          <div className="timeline-rail">
            {timeline.map((item,i)=><article className="timeline-item" key={item.year}><div className="timeline-node">{i+1}</div><span className="timeline-year">{item.year}</span><h3>{item.title}</h3><p>{item.detail}</p><small>{item.status}</small></article>)}
          </div>
          <div className="timeline-footer"><span>APERTURAS · TRANSFORMACIONES · CIERRES · PERMANENCIAS</span><span>FECHAS POR VERIFICAR</span></div>
        </section>

        <section className="archive-section" id="archivo">
          <div className="archive-intro"><Eyebrow>08 / ARCHIVO VIVO</Eyebrow><h2>Las pruebas<br/>también <em>recuerdan.</em></h2><p>Fotografías, documentos, voces y sonidos: materiales que permiten reconstruir las historias y contrastar las memorias.</p><div className="archive-folder"><span>CARPETA</span><b>CDN_1990—2026</b><small>ARCHIVO EN CONSTRUCCIÓN</small></div></div>
          <div className="archive-explorer">
            <div className="archive-tabs">{archiveItems.map(item=><button key={item.id} className={activeArchive===item.id?"selected":""} onClick={()=>setActiveArchive(item.id)}>{item.kind}</button>)}</div>
            <div className="archive-preview">
              <div className="archive-preview-art"><span>{selectedArchive.symbol}</span><small>{selectedArchive.kind} / 00{archiveItems.indexOf(selectedArchive)+1}</small><b>ARCHIVO<br/>PENDIENTE</b></div>
              <div className="archive-preview-copy"><span className="archive-state">{selectedArchive.status}</span><h3>{selectedArchive.title}</h3><p>{selectedArchive.description}</p><div className="archive-meta"><span>ESTADO DEL MATERIAL</span><b>{selectedArchive.status.toUpperCase()}</b></div></div>
            </div>
            <div className="archive-foot">Los documentos, fotografías y registros se publicarán con sus datos de procedencia, permisos y contexto.</div>
          </div>
        </section>

        <section className="stories-section" id="historias">
          <div className="stories-top"><Eyebrow light>09 / LOS TRES PRODUCTOS PERIODÍSTICOS</Eyebrow><span>UNA INVESTIGACIÓN · TRES FORMAS DE CONTAR</span></div>
          <h2>La memoria toma<br/><em>distintas formas.</em></h2>
          <div className="product-stack">
            <article className="product-card product-report">
              <div className="product-index">01 <span>/ TEXTO + IMAGEN</span></div>
              <div className="product-visual report-visual"><span>REPORTAJE<br/>MULTIMEDIA</span><b>LOS LUGARES<br/>QUE CALI DEJÓ<br/>DE NOMBRAR</b><i>✳</i></div>
              <div className="product-copy"><span className="product-status">● {productConfig.report.status}</span><h3>{productConfig.report.title}</h3><p>{productConfig.report.subtitle}</p><div className="product-specs"><span>1.500–2.000 PALABRAS</span><span>FOTOGRAFÍAS</span><span>FUENTES Y DATOS</span><span>LÍNEA DE TIEMPO</span></div><button onClick={()=>scrollTo("guardian")} className="text-link">PRÓXIMAMENTE <b>↗</b></button></div>
            </article>
            <article className="product-card product-audio">
              <div className="product-index">02 <span>/ SONIDO + VOZ</span></div>
              <div className="product-visual audio-visual"><div className="sound-wave">{Array.from({length:31},(_,i)=><i key={i} style={{height:`${15+((i*17)%62)}%`}} />)}</div><span>PIEZA SONORA</span><b>MEMORIAS<br/>QUE TODAVÍA<br/>SUENAN</b></div>
              <div className="product-copy"><span className="product-status">● {productConfig.audio.status}</span><h3>{productConfig.audio.title}</h3><p>{productConfig.audio.subtitle}</p><div className="product-specs"><span>ENTREVISTAS</span><span>SONIDOS DE AMBIENTE</span><span>ARCHIVO AUTORIZADO</span><span>TRANSCRIPCIÓN</span></div><button onClick={()=>scrollTo("guardian")} className="text-link">PRÓXIMAMENTE <b>↗</b></button></div>
            </article>
          </div>
        </section>

        <section className="guardian-section" id="guardian">
          <div className="guardian-top"><Eyebrow light>10 / PRODUCTO 03 · INTELIGENCIA ARTIFICIAL</Eyebrow><span>PROTOTIPO EN INTEGRACIÓN</span></div>
          <div className="guardian-layout">
            <div className="guardian-copy">
              <div className="guardian-orbit"><span>✳</span><i /><b>ARCHIVO<br/>CONECTADO</b></div>
              <h2>El Guardián<br/><em>de la Memoria.</em></h2>
              <p className="guardian-question">¿Qué quieres<br/>recordar de Cali?</p>
              <p>Una interfaz de consulta sobre un archivo periodístico previamente seleccionado y verificado. Una forma de conversar con los documentos, las voces y las memorias reunidas por la investigación.</p>
              <div className="guardian-rules"><span>RESPUESTAS CON FUENTES</span><span>VACÍOS RECONOCIDOS</span><span>VERSIONES EN CONTRASTE</span></div>
            </div>
            <div className="chat-window">
              <div className="chat-head"><div className="chat-avatar">✳</div><div><b>GUARDIÁN DE LA MEMORIA</b><small>PROTOTIPO · CORPUS PENDIENTE DE CONEXIÓN</small></div><span className="chat-live">● DEMO</span></div>
              <div className="chat-body">
                <div className="chat-date">UNA CONVERSACIÓN CON EL ARCHIVO</div>
                <div className="chat-message guardian-message"><span>GUARDIÁN</span><p>Hola. Soy una interfaz en preparación para explorar la memoria cultural de Cali. Cuando el corpus verificado esté conectado, podré ayudarte a consultar lugares, personajes, fechas y documentos.</p><small>Las respuestas deberán indicar sus fuentes.</small></div>
                {chatMessages.map((m,i)=><div key={i} className={`chat-message ${m.from==="user"?"user-message":"guardian-message"}`}><span>{m.from==="user"?"TÚ":"GUARDIÁN"}</span><p>{m.text}</p></div>)}
                <div className="suggested-questions"><span>PUEDES PREGUNTAR</span>{["¿Qué pasó con este teatro?","¿Qué queda de esta memoria?"].map(q=><button key={q} onClick={()=>setChatInput(q)}>{q} ↗</button>)}</div>
              </div>
              <form className="chat-input" onSubmit={submitQuestion}><input value={chatInput} onChange={e=>setChatInput(e.target.value)} placeholder="Escribe una pregunta sobre Cali..." aria-label="Escribe una pregunta"/><button type="submit" aria-label="Enviar pregunta">↑</button></form>
              <div className="chat-disclaimer">MODO DEMOSTRACIÓN · NO CONSULTA AÚN EL ARCHIVO NI GENERA RESPUESTAS DOCUMENTALES.</div>
            </div>
          </div>
          <div className="guardian-integration"><span>PARA INTEGRACIÓN FUTURA</span><p>[EMBED DEL CHATBOT PENDIENTE] · Sustituir el panel de demostración por el iframe, endpoint o componente conectado al corpus. Ver instrucciones en README.</p></div>
        </section>

        <section className="ai-section">
          <div className="ai-heading"><Eyebrow>11 / IA COMO COMPONENTE ESTRUCTURAL</Eyebrow><h2>La tecnología<br/>puede conectar.<br/><em>No puede dar fe.</em></h2></div>
          <div className="ai-content">
            <p className="ai-lead">La inteligencia artificial no es un adorno ni una fuente periodística autónoma. Es una herramienta para organizar y explorar un archivo construido y seleccionado por el equipo.</p>
            <div className="ai-capabilities">
              {["Organizar información","Analizar documentos","Identificar relaciones","Comparar información","Encontrar patrones","Facilitar la consulta del corpus","Conectar lugares, personas y fechas","Alimentar el Guardián"].map((x,i)=><div key={x}><span>0{i+1}</span>{x}<b>↗</b></div>)}
            </div>
            <div className="ai-warning"><span>EL LÍMITE ES CLARO</span><p>La IA no reemplaza la reportería, las fuentes humanas, la verificación ni las decisiones editoriales. No inventa testimonios, no fabrica documentos históricos y no completa vacíos como si fueran hechos.</p></div>
          </div>
        </section>

        <section className="transparency-section" id="transparencia">
          <div className="transparency-heading"><Eyebrow light>12 / TRANSPARENCIA Y CRITERIOS ÉTICOS</Eyebrow><h2>Cómo se construye<br/>lo que <em>contamos.</em></h2><p>La confianza también hace parte de la historia. Estos son los criterios que guían el trabajo y que acompañarán la publicación de los materiales.</p></div>
          <div className="ethics-list">
            {[
              ["01","Verificación","Las afirmaciones relevantes deberán contrastarse con fuentes humanas, documentos y datos disponibles."],
              ["02","Consentimiento","Entrevistas, fotografías, audios y documentos personales se utilizarán con las autorizaciones correspondientes."],
              ["03","Transparencia sobre IA","Se informará qué tareas apoyó la inteligencia artificial y cuáles fueron realizadas y decididas por el equipo."],
              ["04","Protección de datos","Los datos personales se protegerán cuando sea necesario y se evaluará qué información puede publicarse."],
              ["05","No fabricación","No se crearán testimonios ni documentos históricos artificiales para presentarlos como reales."],
              ["06","Derecho de respuesta","Las personas o instituciones mencionadas podrán responder cuando corresponda."],
              ["07","Supervisión humana","Las respuestas y resultados generados por IA serán revisados por el equipo periodístico."],
              ["08","Memoria y versiones","Se diferenciarán hechos verificados, recuerdos y testimonios; las contradicciones se harán visibles."]
            ].map(([n,t,d],i)=><div className={`ethics-item ${openEthics===i?"expanded":""}`} key={n}><button onClick={()=>setOpenEthics(openEthics===i?-1:i)}><span>{n}</span><b>{t}</b><i>{openEthics===i?"−":"+"}</i></button>{openEthics===i&&<p>{d}</p>}</div>)}
          </div>
          <div className="transparency-footer"><span>LA IA APOYA EL PROCESO.</span><b>LA RESPONSABILIDAD PERIODÍSTICA ES HUMANA.</b></div>
        </section>

        <section className="status-section">
          <div className="status-title"><Eyebrow>13 / BITÁCORA DEL PROYECTO</Eyebrow><h2>Una investigación<br/><em>en movimiento.</em></h2><p>Estado de los componentes según el documento base del proyecto.</p></div>
          <div className="status-table">{projectStatus.map(([label,status],i)=><div key={label} className="status-row"><span>0{i+1}</span><b>{label}</b><em>{status}</em><i>↗</i></div>)}</div>
          <div className="project-links"><div><span>PLANIFICACIÓN</span><b>Notion — Guía del proyecto</b><small>[ENLACE PENDIENTE]</small></div><div><span>TRAZABILIDAD DE IA</span><b>Registro de prompts</b><small>[ARCHIVO / ENLACE PENDIENTE]</small></div></div>
        </section>

        <section className="team-section">
          <div className="team-head"><Eyebrow light>14 / QUIÉNES INVESTIGAN</Eyebrow><h2>Detrás de cada<br/><em>memoria, una voz.</em></h2><p>Equipo del proyecto · Universidad Autónoma de Occidente · Comunicación Social – Periodismo · Curso Periodismo e Inteligencia Artificial · 2026</p></div>
          <div className="team-grid">{team.map((person,i)=><article className="team-card" key={person.name}><div className={`team-monogram monogram-${i+1}`}>{person.mark}</div><span>INTEGRANTE 0{i+1}</span><h3>{person.name}</h3><p>{person.degree}</p><button onClick={()=>setShowAllRoles(!showAllRoles)}>{showAllRoles?"OCULTAR RESPONSABILIDADES":"VER RESPONSABILIDADES"} <b>{showAllRoles?"−":"+"}</b></button>{showAllRoles&&<ul>{person.role.map(r=><li key={r}>{r}</li>)}</ul>}</article>)}</div>
        </section>

        <section className="closing-section">
          <div className="closing-stamp">CALI<br/>NO OLVIDA<br/><i>TODO</i></div>
          <p className="closing-kicker">UNA PREGUNTA PARA SEGUIR RECORRIENDO LA CIUDAD</p>
          <h2>¿Qué historias<br/>desaparecen cuando<br/>dejamos de nombrar<br/><em>los lugares que las hicieron posibles?</em></h2>
          <div className="closing-bottom"><span>CALI DEJÓ DE NOMBRARLOS / 2026</span><button onClick={()=>scrollTo("inicio")}>VOLVER AL COMIENZO ↑</button></div>
        </section>
      </main>

      <footer className="footer">
        <div className="footer-main"><a className="footer-logo" href="#inicio">CALI DEJÓ<br/><em>DE NOMBRARLOS.</em></a><p>Un proyecto periodístico multimedia de investigación y memoria cultural apoyado en inteligencia artificial generativa.</p><div className="footer-nav">{navItems.slice(0,5).map(([l,id])=><a href={`#${id}`} key={id}>{l}</a>)}</div></div>
        <div className="footer-bottom"><span>MARÍA PAULA BUITRAGO TORO · DANA MORENO LÓPEZ · JOSÉ MAURICIO ALARCÓN LOZADA</span><span>UNIVERSIDAD AUTÓNOMA DE OCCIDENTE · 2026</span><span>FUENTES, ARCHIVO Y CRITERIOS EDITORIALES EN ACTUALIZACIÓN</span></div>
      </footer>

      {activeCase&&<div className="modal-backdrop" role="presentation" onClick={()=>setActiveCase(null)}><section className="case-modal" role="dialog" aria-modal="true" aria-label={`Ficha ${activeCase.name}`} onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setActiveCase(null)} aria-label="Cerrar">×</button><Eyebrow>FICHA DE INVESTIGACIÓN</Eyebrow><span className="modal-status">{activeCase.status}</span><h2>{activeCase.name}</h2><p className="modal-summary">{activeCase.summary}</p><div className="modal-fields">{[["Ubicación",activeCase.location],["Época",activeCase.period],["Qué representó",activeCase.whatItWas],["Qué ocurrió",activeCase.whatHappened],["Estado actual",activeCase.currentState],["Testimonios",activeCase.testimony],["Fuentes","[FUENTES POR INCORPORAR]"]].map(([k,v])=><div key={k}><b>{k}</b><p>{v}</p></div>)}</div><small>Esta ficha es editable desde src/data.js. No contiene hallazgos confirmados.</small></section></div>}
    </div>
  );
}


window.CDNApp = App;
